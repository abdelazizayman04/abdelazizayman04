SELECT "title","season" FROM "episodes" WHERE "episode_in_season"=1;
