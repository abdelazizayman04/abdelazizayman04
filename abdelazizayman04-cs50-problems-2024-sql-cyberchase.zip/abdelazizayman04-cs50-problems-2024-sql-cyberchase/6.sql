SELECT "title" FROM "episodes" WHERE "season"= 6 AND "air_date"<"2008-01-01";
