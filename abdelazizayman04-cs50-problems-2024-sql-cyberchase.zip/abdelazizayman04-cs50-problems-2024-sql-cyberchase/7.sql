SELECT "title","topic" FROM "episodes" WHERE "topic" LIKE '%fractions%';
