select "name","city" from "schools" where "type"= 'Public School';
