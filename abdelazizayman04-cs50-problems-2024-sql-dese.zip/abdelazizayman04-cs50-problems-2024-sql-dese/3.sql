select avg("per_pupil_expenditure") as "Average District Per-Pupil Expenditure" from "expenditures";
