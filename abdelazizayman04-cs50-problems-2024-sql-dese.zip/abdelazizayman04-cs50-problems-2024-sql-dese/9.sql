 select "name" from "districts" where "id"in(select "district_id"from expenditures order by pupils asc limit 1);
