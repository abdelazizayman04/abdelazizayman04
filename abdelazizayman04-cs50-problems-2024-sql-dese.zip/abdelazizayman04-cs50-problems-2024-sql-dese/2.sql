SELECT "name"FROM "districts" WHERE "name" LIKE '%(non-op)';

