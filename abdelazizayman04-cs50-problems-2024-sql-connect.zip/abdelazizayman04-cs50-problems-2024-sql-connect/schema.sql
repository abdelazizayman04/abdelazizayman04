CREATE TABLE "users" (
    "id" INTEGER,
    "first_name" TEXT,
    "last_name" TEXT,
    "user_name" TEXT unique,
    "password" text,
    PRIMARY KEY ("id")
);
create table"schools"(
    "id"integer,
    "name"text,
    "school_type"text,
    "location"text,
    "founding_year"integer,
    primary key("id")
);
create table"companies"(
    "id"integer,
    "name"text,
    "industry"text,
    "location"text,
    primary key("id")
);
create table"user connection"(
    "user1_id"integer,
    "user2_id"integer,
    foreign key("user1_id")references"users"("id"),
    foreign key("user2_id")references"users"("id")
);
create table"school connection"(
    "user_id"integer,
    "start_date"datetime,
    "end_date"datetime,
    "type of degree"text,
    foreign key("user_id")references"users"("id")
);
create table"company connection"(
    "user_id"integer,
    "company_id"integer,
    "start_date"datetime,
    "end_date"datetime,
    "title"text,
    foreign key("user_id")references"users"("id"),
    foreign key("company_id")references"companies"("id")
);
