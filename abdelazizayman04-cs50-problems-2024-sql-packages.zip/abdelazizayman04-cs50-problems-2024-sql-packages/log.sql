
-- *** The Lost Letter ***
SELECT * FROM "addresses"
 WHERE "address"="900 Somerville Avenue";

SELECT * FROM "addresses"
WHERE "address" like "2 fin%";

SELECT *FROM "packages"
WHERE "from_address_id" = (
        SELECT "id"
        FROM "addresses"
        WHERE "address" = '900 Somerville Avenue'
    )
    AND "to_address_id" = (
        SELECT "id"
        FROM "addresses"
        WHERE "address" LIKE '2 fin%'
    );
SELECT *FROM "scans"
WHERE "package_id" = (
    SELECT "id"
    FROM "packages"
    WHERE "from_address_id" = (
        SELECT "id"
        FROM "addresses"
        WHERE "address" = '900 Somerville Avenue'
    )
    AND "to_address_id" = (
        SELECT "id"
        FROM "addresses"
        WHERE "address" LIKE '2 fin%'
    )
);

-- *** The Devious Delivery ***
select * from "packages" where "from_address_id" is null;

select * from "addresses" where "id" =50;

select "id" from "packages" where "from_address_id" is null;

select * from "scans" where "package_id"=(
    select "id" from "packages" where "from_address_id" is null
);

select "address_id" from "scans" where "package_id"=(select "id" from "package" where "from_address_id" is null
) and "action"='drop';

SELECT *
FROM "addresses"
WHERE "id" = (
    SELECT "address_id"
    FROM "scans"
    WHERE "package_id" = (
        SELECT "id"
        FROM "packages"
        WHERE "from_address_id" IS NULL
    )
    AND action = 'Drop'
);


-- *** The Forgotten Gift ***

select "id"from "addresses" where "address"="109 Tileston Street"

select "id"from "addresses" where "address"="728 Maple Place";

SELECT *FROM "packages"
WHERE "from_address_id" = (
    SELECT "id"FROM "addresses"
    WHERE "address" = '109 Tileston Street'
) OR "to_address_id" = (
    SELECT "id"
    FROM "addresses"
    WHERE "address" = '728 Maple Place'
);

SELECT *FROM "scans"
WHERE "package_id" = (
    SELECT "id" FROM "packages"
    WHERE "from_address_id" = (
        SELECT "id" FROM "addresses"
        WHERE "address" = '109 Tileston Street'
    )
);


SELECT "driver_id" FROM "scans"
WHERE "package_id" = (
    SELECT "id" FROM "packages"
    WHERE "from_address_id" = (
        SELECT "id" FROM "addresses"
        WHERE "address" = '109 Tileston Street'
    )
)
order by "timestamp"desc limit 1;

SELECT "name"FROM "drivers"
WHERE "id" = (
    SELECT "driver_id" FROM "scans"
    WHERE "package_id" = (
        SELECT "id" FROM "packages"
        WHERE "from_address_id" = (
            SELECT "id" FROM "addresses"
            WHERE "address" = '109 Tileston Street'
        )
    )
    ORDER BY "timestamp" DESC
    LIMIT 1
);
