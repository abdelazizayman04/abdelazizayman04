select  "teams"."name",round(avg("salaries"."salary"),2) as "average salary"  from "salaries"
join "teams" on "teams"."id"="salaries"."team_id"
where "salaries"."year"=2001
group by "teams"."name"
order by "average salary" asc
limit 5;
