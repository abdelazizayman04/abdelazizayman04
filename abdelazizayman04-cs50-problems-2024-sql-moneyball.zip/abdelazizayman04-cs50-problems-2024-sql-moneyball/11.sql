select "players"."first_name" , "players"."last_name",NULLIF("salaries"."salary" / "performances"."H", 0) AS "dollars_per_hit"
from "players"
join "salaries" on "salaries"."player_id"="players"."id"
join "performances" on "performances"."player_id" ="players"."id" and "performances"."year"="salaries"."year"
where "performances"."year"=2001 and "performances"."H" >0
ORDER BY
    "dollars_per_hit",
    "players"."first_name",
    "players"."last_name"
LIMIT 10;
