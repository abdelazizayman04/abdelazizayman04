select "birth_city", "birth_state", "birth_country" from "players" where "first_name"='Jackie' and "last_name"='Robinson';
