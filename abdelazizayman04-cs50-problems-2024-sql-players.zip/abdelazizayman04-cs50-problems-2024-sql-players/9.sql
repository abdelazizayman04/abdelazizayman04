select
    first_name,
    last_name
from
    players
where
    final_game between '2022-01-01' and '2022-12-31'
order by
    first_name,
    last_name;
