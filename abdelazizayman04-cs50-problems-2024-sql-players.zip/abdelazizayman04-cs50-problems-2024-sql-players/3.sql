SELECT"id" FROM "players" WHERE "debut" is null;

