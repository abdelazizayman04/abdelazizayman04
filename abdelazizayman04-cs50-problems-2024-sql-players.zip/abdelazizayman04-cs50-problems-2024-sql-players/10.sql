select "height" as "maximum height" from "players" where "birth_country"='USA' order by "height"desc limit 10;
