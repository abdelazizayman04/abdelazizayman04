SELECT "bats" FROM "players" WHERE "first_name"='Babe' AND "last_name"='Ruth';
