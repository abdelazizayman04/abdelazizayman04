select
    first_name,
    last_name
from
    players
where
    birth_country is not 'USA'
order by
    first_name,
    last_name;
