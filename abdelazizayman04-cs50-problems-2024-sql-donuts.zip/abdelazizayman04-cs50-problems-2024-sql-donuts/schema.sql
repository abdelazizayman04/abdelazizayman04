CREATE TABLE donuts (
    id INTEGER PRIMARY KEY,
    donut_name TEXT,
    gluten_free BOOLEAN,
    price TEXT
);

CREATE TABLE ingredients (
    id INTEGER PRIMARY KEY,
    name TEXT,
    price_per_unit TEXT,
    unit TEXT
);

CREATE TABLE donut_ingredient (
    donut_id INTEGER,
    ingredient_id INTEGER,
    FOREIGN KEY (donut_id) REFERENCES donuts (id),
    FOREIGN KEY (ingredient_id) REFERENCES ingredients (id),
    PRIMARY KEY (donut_id, ingredient_id)
);

CREATE TABLE customers (
    id INTEGER PRIMARY KEY,
    first_name TEXT,
    last_name TEXT
);

CREATE TABLE orders (
    id INTEGER PRIMARY KEY,
    donut_id INTEGER,
    customer_id INTEGER,
    quantity INTEGER,
    FOREIGN KEY (donut_id) REFERENCES donuts (id),
    FOREIGN KEY (customer_id) REFERENCES customers (id)
);

