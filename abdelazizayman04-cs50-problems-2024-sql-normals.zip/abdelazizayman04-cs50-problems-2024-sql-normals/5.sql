SELECT max("0m") FROM "normals";
