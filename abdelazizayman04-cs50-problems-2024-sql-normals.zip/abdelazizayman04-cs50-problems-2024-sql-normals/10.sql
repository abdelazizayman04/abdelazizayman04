SELECT COUNT(DISTINCT "latitude") FROM "normals";
