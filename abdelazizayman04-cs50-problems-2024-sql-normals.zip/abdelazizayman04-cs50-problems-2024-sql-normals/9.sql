SELECT "longitude","latitude","0m" FROM "normals" ORDER BY "0m" DESC , "latitude" DESC LIMIT 10;
