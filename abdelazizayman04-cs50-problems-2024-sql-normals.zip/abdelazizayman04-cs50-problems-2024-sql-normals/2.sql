SELECT "225m" FROM "normals" WHERE "latitude"=42.5 AND "longitude"=-69.5;
