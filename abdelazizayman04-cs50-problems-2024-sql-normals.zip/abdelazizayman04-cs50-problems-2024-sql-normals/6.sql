SELECT "longitude", "latitude","50m" FROM "normals" WHERE "latitude" BETWEEN 0 AND 20  AND "longitude" BETWEEN 55 AND 75;
