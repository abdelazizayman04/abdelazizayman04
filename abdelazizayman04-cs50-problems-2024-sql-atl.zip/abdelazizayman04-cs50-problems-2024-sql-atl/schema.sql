CREATE TABLE passengers (
    id INTEGER PRIMARY KEY,
    first_name TEXT,
    last_name TEXT,
    age INTEGER
);

CREATE TABLE airlines (
    id INTEGER PRIMARY KEY,
    name TEXT,
    concourse TEXT
);

CREATE TABLE flights (
    id INTEGER PRIMARY KEY,
    airline_id INTEGER,
    flight_number INTEGER,
    from_airport_code INTEGER,
    to_airport_code INTEGER,
    departure DATETIME,
    arrival DATETIME,
    FOREIGN KEY (airline_id) REFERENCES airlines(id)
);

CREATE TABLE check_ins (
    id INTEGER PRIMARY KEY,
    passenger_id INTEGER,
    flight_id INTEGER,
    date_time DATETIME,
    FOREIGN KEY (passenger_id) REFERENCES passengers(id),
    FOREIGN KEY (flight_id) REFERENCES flights(id)
);

