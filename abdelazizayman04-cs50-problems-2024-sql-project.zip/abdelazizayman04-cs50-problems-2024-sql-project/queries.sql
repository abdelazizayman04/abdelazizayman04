--retrieve all products in the Apple Store:
SELECT * FROM Products;
--add a new product to the Apple Store:
INSERT INTO Products (product_id, name, category, price)
VALUES (1, 'iPhone 13', 'Smartphones', 799.99),
       (2, 'MacBook Pro', 'Laptops', 1499.99),
       (3, 'AirPods Pro', 'Accessories', 249.99);

--modify the price of a product in the Apple Store:
UPDATE Products
SET price = 1099.99
WHERE product_id = 1;
--remove a product from the Apple Store:
DELETE FROM Products
WHERE product_id = 1;

--Inserting data into Customers table:
INSERT INTO Customers (customer_id, first_name, last_name, email)
VALUES (1, 'John', 'Doe', 'johndoe@example.com'),
       (2, 'Jane', 'Smith', 'janesmith@example.com');

--Inserting data into Orders table:
INSERT INTO Orders (order_id, customer_id, total_amount)
VALUES (1, 1, 1049.98),
       (2, 2, 799.99);

--Inserting data into OrderItems table:
INSERT INTO OrderItems (order_item_id, order_id, product_id, quantity, price)
VALUES (1, 1, 1, 1, 799.99),
       (2, 1, 3, 2, 499.98),
       (3, 2, 2, 1, 1499.99);
-- get first_name and last_name who has order_id=1
SELECT first_name, last_name
FROM Customers
WHERE customer_id = (
    SELECT customer_id
    FROM Orders
    WHERE order_id = 1
);
--Selecting data from multiple tables (Join example):
SELECT Orders.order_id, Customers.first_name, Customers.last_name, Products.name, OrderItems.quantity, OrderItems.price
FROM Orders
JOIN Customers ON Orders.customer_id = Customers.customer_id
JOIN OrderItems ON Orders.order_id = OrderItems.order_id
JOIN Products ON OrderItems.product_id = Products.product_id;


