# Design Document

By Abdelaziz ayman

Video overview: <https://youtu.be/JXpKgtrPd0g?si=2i2fZX8iaE0awsG4>

## Scope
Purpose of the Database:
The purpose of the Apple Store database is to facilitate the management of products, customers, orders, and order items for an online store specializing in Apple products. It aims to provide a structured system for storing and organizing data related to product inventory, customer information, and order processing.
In Scope:
Products: Information about Apple products, including their names, categories, and prices.
Customers: Details of customers such as their names and email addresses.
Orders: Records of orders placed by customers, including order IDs, dates, and total amounts.
Order Items: Specific items within each order, including the product ID, quantity, and price.
Outside Scope:
1-Manufacturing Process: Details about how Apple products are manufactured or sourced are outside the scope of this database.
2-Marketing and Sales Analytics: Analysis of marketing campaigns, sales trends, or customer behavior analytics is not part of this database's scope.

## Functional Requirements
this database will support:
 *Manage products, customers, orders, and order items; view lists and update information.
*Beyond Scope: Database schema modifications, advanced data analysis, and system administration tasks.

## Representation
![apple store](ERD.drawio-1.png)

### Entities

1-Products:

product_id (INT, PRIMARY KEY): Unique identifier for each product.
name (TEXT, NOT NULL): Name of the product.
category (TEXT, NOT NULL): Category to which the product belongs.
price (NUMERIC, NOT NULL): Price of the product.

2-Customers:
customer_id (INT, PRIMARY KEY): Unique identifier for each customer.
first_name (TEXT, NOT NULL): First name of the customer.
last_name (TEXT, NOT NULL): Last name of the customer.
email (TEXT, NOT NULL): Email address of the customer.

3-Orders:
order_id (INT, PRIMARY KEY): Unique identifier for each order.
customer_id (INT, NOT NULL, FOREIGN KEY): Identifier of the customer who placed the order.
order_date (DATETIME, DEFAULT CURRENT_TIMESTAMP): Date and time when the order was placed.
total_amount (INT, NOT NULL): Total amount of the order.

Order Items:
4-order_item_id (INT, PRIMARY KEY): Unique identifier for each order item.
order_id (INT, NOT NULL, FOREIGN KEY): Identifier of the order to which the item belongs.
product_id (INT, NOT NULL, FOREIGN KEY): Identifier of the product in the order item.
quantity (INT, NOT NULL): Quantity of the product in the order item.
price (NUMERIC, NOT NULL): Price of the product in the order item.

### Relationships

In this section you should include your entity relationship diagram and describe the relationships between the entities in your database.

## Optimizations

Index Creation: Implemented index (idx_product_name) on name column in Products table for quicker product name searches.
Views for Representation: Designed OrderDetails view combining order, customer, and product data; and LowStockProducts view for low-stock products.

## Limitations

The limitations include data integrity constraints, scalability concerns, security measures, and challenges in representing complex relationships and advanced analytics.
