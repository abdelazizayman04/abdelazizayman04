-- Create database for Apple Store

-- Create table for products

CREATE TABLE Products (
    product_id INT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    price NUMERIC NOT NULL CHECK (price != 0)
);


-- Create table for customers
CREATE TABLE Customers (
    customer_id INT  PRIMARY KEY,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT NOT NULL
);


-- Create table for orders
CREATE TABLE Orders (
    order_id INT not null PRIMARY KEY,
    customer_id INT NOT NULL,
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_amount INT NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);

-- Create table for order items
CREATE TABLE"OrderItems" (
    "order_item_id" INT not null PRIMARY KEY,
    "order_id" INT NOT NULL,
    "product_id" INT NOT NULL,
    "quantity" INT NOT NULL,
    "price"numeric NOT NULL,
    FOREIGN KEY ("order_id") REFERENCES "Orders"("order_id"),
    FOREIGN KEY ("product_id") REFERENCES "Products"("product_id")
);

-- Create index on product name for faster search
CREATE INDEX idx_product_name ON Products(name);

-- Create view to display order details with customer information
CREATE VIEW OrderDetails AS
SELECT o.order_id, o.order_date, c.name AS customer_name, p.name AS product_name, oi.quantity, oi.price
FROM Orders o
INNER JOIN Customers c ON o.customer_id = c.customer_id
INNER JOIN OrderItems oi ON o.order_id = oi.order_id
INNER JOIN Products p ON oi.product_id = p.product_id;

-- Create view to display products with low stock
CREATE VIEW LowStockProducts AS
SELECT product_id, name, category, stock
FROM Products
WHERE stock < 10;
